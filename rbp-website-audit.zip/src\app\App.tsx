import { Route, Routes } from 'react-router-dom'
import { SiteLayout } from '../components/layout/SiteLayout.tsx'
import { CheckoutPage } from '../pages/CheckoutPage.tsx'
import { CollectionsPage } from '../pages/CollectionsPage.tsx'
import { EventsPage } from '../pages/EventsPage.tsx'
import { HomePage } from '../pages/HomePage.tsx'
import { ProductDetailPage } from '../pages/ProductDetailPage.tsx'

export default function App() {
  return (
    <Routes>
      <Route element={<SiteLayout />}>
        <Route index element={<HomePage />} />
        <Route path="collections" element={<CollectionsPage />} />
        <Route path="products/:slug" element={<ProductDetailPage />} />
        <Route path="checkout" element={<CheckoutPage />} />
        <Route path="events" element={<EventsPage />} />
      </Route>
    </Routes>
  )
}