import { Link } from 'react-router-dom'
import { asset } from '../../lib/assets.ts'

type Props = {
  title: string
  image: string
  category: string
}

export function CollectionCard({ title, image, category }: Props) {
  return (
    <Link
      to={`/collections?category=${encodeURIComponent(category)}`}
      className="group flex min-h-[126px] flex-col overflow-hidden rounded-rbp border border-rbp-border bg-rbp-card transition hover:border-rbp-accent"
    >
      <div className="h-[82px] w-full overflow-hidden">
        <img src={asset(image)} alt={title} className="h-full w-full object-cover transition group-hover:scale-105" />
      </div>
      <p className="py-1 text-center text-base text-rbp-text">{title}</p>
      <p className="pb-2 text-center text-xs text-rbp-accent-gold">Shop Now →</p>
    </Link>
  )
}