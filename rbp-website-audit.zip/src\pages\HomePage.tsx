import { useNavigate } from 'react-router-dom'
import { CollectionCard } from '../components/commerce/CollectionCard.tsx'
import { OrangeLink, OrangeButton, OutlineButton } from '../components/ui/Buttons.tsx'
import { GothicHeading } from '../components/ui/GothicHeading.tsx'
import {
  IconAward,
  IconCalendar,
  IconCalendarLight,
  IconCart,
  IconGem,
  IconPeople,
  IconPin,
  IconShield,
} from '../components/ui/Icons.tsx'
import { OrangeDivider } from '../components/ui/OrangeDivider.tsx'
import { asset } from '../lib/assets.ts'

const collections = [
  { title: 'Navel Jewelry', image: 'products/product-01.jpg', category: 'Navel Jewelry' },
  { title: 'Tongue Barbells', image: 'products/product-07.jpg', category: 'Tongue Barbells' },
  { title: 'Hinged Clickers', image: 'products/product-02.jpg', category: 'Hinged Clickers' },
  { title: 'Segment Rings', image: 'products/product-06.jpg', category: 'Segment Rings' },
  { title: 'Eyebrow Jewelry', image: 'products/product-05.jpg', category: 'Eyebrow' },
  { title: 'Ear Jewelry', image: 'products/product-09.jpg', category: 'Ear Jewelry' },
]

const clientResults = [
  'showcase/client-nostril-septum.jpg',
  'showcase/client-ear-multiple-piercings.jpg',
  'showcase/client-eyebrow.jpg',
  'showcase/client-lip.jpg',
  'showcase/client-ear-tunnel.jpg',
]

const benefits = [
  { icon: IconShield, title: 'Safe & Sterile', sub: 'Procedures' },
  { icon: IconGem, title: 'Premium', sub: 'Body Jewelry' },
  { icon: IconAward, title: 'Certified Piercer', sub: '& Member of TBPAP' },
  { icon: IconPeople, title: 'Events &', sub: 'Community' },
]

export function HomePage() {
  const navigate = useNavigate()

  return (
    <div className="w-full">
      <section className="relative w-full border-b border-rbp-divider">
        <div className="grid w-full lg:grid-cols-[minmax(0,512px)_1fr]">
          <div className="relative min-h-[280px] bg-rbp-surface px-6 py-8 sm:px-12 lg:min-h-[309px] lg:py-7">
            <p className="mb-2 tracking-[5px] text-rbp-cream text-xs">ROMELL BODY PIERCING</p>
            <GothicHeading as="h1" className="text-[2.75rem] leading-[0.95] sm:text-[4rem] lg:text-[4.2rem]">
              <span className="block text-rbp-accent">Professional</span>
              <span className="block">
                Body <span className="text-rbp-pierce">Piercing</span>
              </span>
              <span className="block text-rbp-accent">
                & <span className="text-rbp-pierce">Jewelry</span>
              </span>
            </GothicHeading>
            <p className="mt-4 max-w-sm text-sm text-rbp-text">
              Expert piercing services, premium body jewelry, and a trusted name in the Philippine piercing
              community.
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              <OrangeButton icon={<IconCalendar size={18} />} onClick={() => navigate('/events')}>
                Book a Piercing
              </OrangeButton>
              <OutlineButton icon={<IconCart size={18} />} onClick={() => navigate('/collections')}>
                Shop Jewelry
              </OutlineButton>
            </div>
          </div>
          <div className="relative min-h-[220px] lg:min-h-[309px]">
            <img
              src={asset('banners/homepage-hero-pierced-ear.jpg')}
              alt="Professional piercing showcase"
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute bottom-0 right-0 top-0 hidden w-[min(100%,200px)] bg-rbp-surface/90 p-4 lg:block xl:w-[176px]">
              <ul className="space-y-8 pt-2">
                {benefits.map(({ icon: Icon, title, sub }) => (
                  <li key={title} className="flex gap-3 text-[13px] text-rbp-text">
                    <Icon />
                    <span>
                      {title}
                      <br />
                      {sub}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
        <OrangeDivider />
      </section>

      <section className="w-full px-4 py-8 sm:px-8">
        <div className="mb-6 flex items-center justify-center gap-4">
          <div className="h-3 w-24 bg-gradient-to-r from-transparent to-rbp-accent opacity-60" />
          <GothicHeading className="text-center text-3xl">Featured Collections</GothicHeading>
          <div className="h-3 w-24 bg-gradient-to-l from-transparent to-rbp-accent opacity-60" />
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
          {collections.map((c) => (
            <CollectionCard key={c.title} {...c} />
          ))}
        </div>
      </section>

      <section className="w-full border-y border-rbp-divider px-4 py-6 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <GothicHeading className="mb-4 text-[2rem]">Client Results</GothicHeading>
            <div className="flex flex-wrap gap-2">
              {clientResults.map((img) => (
                <img
                  key={img}
                  src={asset(img)}
                  alt="Client piercing result"
                  className="h-[166px] w-[calc(20%-6px)] min-w-[100px] flex-1 rounded-[10px] object-cover"
                />
              ))}
            </div>
          </div>
          <div>
            <GothicHeading className="mb-4 text-[2rem]">Events & Community</GothicHeading>
            <div className="flex flex-col gap-2 sm:flex-row">
              <div className="flex-1 overflow-hidden rounded-rbp border border-rbp-border bg-rbp-surface">
                <img
                  src={asset('events/expo-booth-homepage.jpg')}
                  alt="Philippine Tattoo Expo"
                  className="h-[109px] w-full object-cover"
                />
                <div className="p-3">
                  <span className="inline-block rounded-md bg-rbp-accent px-2 py-0.5 text-[10px] font-bold text-black">
                    FEATURED EVENT
                  </span>
                  <p className="mt-1 text-xl font-bold">Philippine Tattoo Expo 2025</p>
                  <div className="mt-2 flex flex-wrap gap-4 text-xs text-rbp-text">
                    <span className="flex items-center gap-1">
                      <IconCalendarLight size={16} /> May 16–18, 2025
                    </span>
                    <span className="flex items-center gap-1">
                      <IconPin size={16} /> SMX Convention Center, Pasay
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex w-full gap-2 sm:w-[150px] sm:flex-col">
                <img
                  src={asset('events/event-awards-homepage.jpg')}
                  alt="Event awards"
                  className="h-[83px] flex-1 rounded-rbp object-cover sm:w-full"
                />
                <img
                  src={asset('events/event-group-homepage.jpg')}
                  alt="Piercing community"
                  className="h-[77px] flex-1 rounded-rbp object-cover sm:w-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="relative w-full px-4 py-8 text-center sm:px-8">
        <p className="tracking-[4px] text-rbp-cream text-sm">PIERCING • JEWELRY • EVENTS • COMMUNITY</p>
        <OrangeLink to="/collections" className="mt-4 inline-flex">
          Explore All Collections →
        </OrangeLink>
      </section>
    </div>
  )
}