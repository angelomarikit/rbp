import { Link } from 'react-router-dom'
import type { Product } from '../../data/types.ts'
import { useCart } from '../../features/cart/CartProvider.tsx'
import { asset } from '../../lib/assets.ts'
import { formatPhp } from '../../lib/format.ts'
import { IconCart, IconHeart } from '../ui/Icons.tsx'

export function ProductCard({ product }: { product: Product }) {
  const { addProduct } = useCart()

  return (
    <article className="flex min-h-[217px] flex-col overflow-hidden rounded-rbp border border-rbp-border bg-rbp-card">
      <Link to={`/products/${product.slug}`} className="relative block h-[135px] w-full overflow-hidden">
        <img
          src={asset(product.imagePath)}
          alt={product.name}
          className="h-full w-full object-cover"
        />
        <span className="absolute right-2 top-2">
          <IconHeart />
        </span>
      </Link>
      <div className="flex flex-1 flex-col px-2 pb-2 pt-1">
        <Link to={`/products/${product.slug}`} className="line-clamp-2 text-xs text-rbp-text hover:text-rbp-accent">
          {product.name}
        </Link>
        <p className="mt-1 text-lg text-rbp-accent">{formatPhp(product.priceCents)}</p>
        <button
          type="button"
          onClick={() => addProduct(product)}
          className="mt-auto flex items-center justify-center gap-2 rounded border border-rbp-border bg-rbp-surface py-1.5 text-xs text-rbp-text hover:border-rbp-accent"
        >
          <IconCart size={13} />
          Add to Cart
        </button>
      </div>
    </article>
  )
}