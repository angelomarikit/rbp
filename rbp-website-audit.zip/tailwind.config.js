/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        rbp: {
          bg: '#010101',
          surface: '#050505',
          card: '#030303',
          accent: '#ff8500',
          'accent-bright': '#ff9b12',
          'accent-gold': '#ffad00',
          border: '#bd6e00',
          'border-light': '#bc6000',
          divider: '#d56b00',
          text: '#ededed',
          muted: '#f0d6aa',
          cream: '#efdbb2',
          pierce: '#edceb1',
        },
      },
      fontFamily: {
        display: [
          'Cloister Black',
          'Old English Text MT',
          'UnifrakturMaguntia',
          'Georgia',
          'serif',
        ],
        body: ['Roboto', 'Arial', 'sans-serif'],
      },
      borderRadius: {
        rbp: '7px',
      },
    },
  },
  plugins: [],
}