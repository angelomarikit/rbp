import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { OrangeButton } from '../components/ui/Buttons.tsx'
import { GothicHeading } from '../components/ui/GothicHeading.tsx'
import { IconAward, IconCart, IconGem, IconShield } from '../components/ui/Icons.tsx'
import { QuantityStepper } from '../components/ui/QuantityStepper.tsx'
import { GEM_VARIANTS, getProductBySlug } from '../data/products.ts'
import { useCart } from '../features/cart/CartProvider.tsx'
import { asset } from '../lib/assets.ts'
import { formatPhp } from '../lib/format.ts'

const GALLERY = [
  'products/navel-barbell-gallery-1.jpg',
  'products/navel-barbell-gallery-2.jpg',
  'products/navel-barbell-gallery-3.jpg',
  'products/navel-barbell-gallery-4.jpg',
]

const tabs = ['Description', 'Specifications', 'Reviews (28)', 'Shipping & Returns'] as const

export function ProductDetailPage() {
  const { slug = 'crystal-navel-barbell' } = useParams()
  const product = getProductBySlug(slug)
  const navigate = useNavigate()
  const { addProduct } = useCart()
  const [qty, setQty] = useState(1)
  const [gem, setGem] = useState(GEM_VARIANTS[0])
  const [activeTab, setActiveTab] = useState<(typeof tabs)[number]>('Description')
  const [hero, setHero] = useState(product?.imagePath ?? 'products/navel-barbell-hero.jpg')

  if (!product) {
    return (
      <div className="p-8 text-center">
        <p>Product not found.</p>
        <Link to="/collections" className="text-rbp-accent">
          Back to collections
        </Link>
      </div>
    )
  }

  const specs = product.specs

  return (
    <div className="w-full">
      <div className="flex items-center gap-2 border-b border-rbp-border-light px-6 py-3 text-sm text-rbp-muted">
        <Link to="/" className="hover:text-rbp-accent">
          Home
        </Link>
        <span>/</span>
        <Link to="/collections" className="hover:text-rbp-accent">
          Shop
        </Link>
        <span>/</span>
        <span>{product.category}</span>
        <span>/</span>
        <span className="text-rbp-text">{product.name}</span>
      </div>

      <section className="grid w-full gap-8 px-4 py-6 lg:grid-cols-[minmax(0,680px)_1fr] lg:px-8">
        <div className="flex gap-3">
          <div className="hidden flex-col gap-2 sm:flex">
            {GALLERY.map((src, i) => (
              <button
                key={src}
                type="button"
                onClick={() => setHero(src)}
                className="h-[100px] w-[93px] overflow-hidden rounded border border-rbp-border"
              >
                <img src={asset(src)} alt={`View ${i + 1}`} className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
          <img
            src={asset(hero)}
            alt={product.name}
            className="min-h-[320px] flex-1 rounded-rbp border border-rbp-border object-cover lg:min-h-[461px]"
          />
        </div>

        <div className="space-y-4">
          <span className="inline-block rounded border border-rbp-border px-2 py-1 text-[10px] uppercase tracking-wide">
            {product.category}
          </span>
          <GothicHeading as="h1" className="text-4xl lg:text-5xl">
            {product.name}
          </GothicHeading>
          <p className="text-rbp-accent text-xl">
            {'★★★★★'.slice(0, product.rating ?? 5)}
            <span className="ml-2 text-sm text-rbp-muted">({product.reviewCount ?? 28} Reviews)</span>
          </p>
          <p className="text-4xl text-rbp-accent">{formatPhp(product.priceCents)}</p>
          <p className="max-w-lg text-sm text-rbp-text">{product.description}</p>

          {specs && (
            <dl className="max-w-lg space-y-2 border-y border-rbp-border py-3 text-sm">
              {[
                ['Material', specs.material],
                ['Thickness (Gauge)', specs.gauge],
                ['Bar Length', specs.barLength],
                ['Gem', specs.gem],
                ['Color / Finish', specs.finish],
              ].map(([label, value]) => (
                <div key={label} className="grid grid-cols-[1fr_auto_1fr] gap-2 border-b border-rbp-border/40 pb-2">
                  <dt className="text-rbp-muted">{label}</dt>
                  <dd>:</dd>
                  <dd className="text-right">{value}</dd>
                </div>
              ))}
            </dl>
          )}

          <p className="text-sm">Quantity</p>
          <div className="flex flex-wrap items-center gap-3">
            <QuantityStepper value={qty} onChange={setQty} />
            <OrangeButton
              icon={<IconCart size={22} />}
              className="min-h-[49px] flex-1 px-8"
              onClick={() => {
                addProduct(product, qty, { key: gem.key, label: gem.label })
                navigate('/checkout')
              }}
            >
              Add to Cart
            </OrangeButton>
            <button
              type="button"
              aria-label="Save to wishlist"
              className="flex h-[49px] w-[50px] items-center justify-center rounded-rbp border border-rbp-border"
            >
              <svg width={24} height={24} viewBox="0 0 24 24" fill="none" aria-hidden>
                <path
                  d="M12 21s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.6-7 10-7 10z"
                  stroke="#ff8500"
                  strokeWidth="1.5"
                />
              </svg>
            </button>
          </div>

          <div className="flex flex-wrap gap-6 pt-4 text-xs text-rbp-text">
            {[
              { icon: IconShield, t1: 'Hypoallergenic', t2: '& Skin Safe' },
              { icon: IconGem, t1: 'Premium', t2: 'Quality' },
              { icon: IconAward, t1: 'Professional', t2: 'Piercing Support' },
            ].map(({ icon: Icon, t1, t2 }) => (
              <div key={t1} className="flex gap-2">
                <Icon size={30} />
                <span>
                  {t1}
                  <br />
                  {t2}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-rbp-border px-4 py-6 lg:px-8">
        <div className="flex flex-wrap gap-6 border-b border-rbp-border text-sm">
          {tabs.map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`pb-2 ${activeTab === tab ? 'border-b-2 border-rbp-accent text-rbp-accent' : 'text-rbp-muted'}`}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="mt-4 grid gap-6 lg:grid-cols-[1fr_auto_1fr]">
          <div className="text-sm leading-relaxed text-rbp-text">
            {activeTab === 'Description' && product.description}
            {activeTab === 'Specifications' && (
              <pre className="whitespace-pre-wrap font-body">{JSON.stringify(specs, null, 2)}</pre>
            )}
            {activeTab.startsWith('Reviews') && <p>Rated highly by clients for comfort and shine.</p>}
            {activeTab.startsWith('Shipping') && (
              <p>Secure shipping across the Philippines. Returns accepted on unopened jewelry within 7 days.</p>
            )}
          </div>
          <div className="hidden h-20 w-px bg-rbp-border lg:block" />
          <div>
            <p className="mb-3 font-bold">Also Available In:</p>
            <div className="flex flex-wrap gap-2">
              {GEM_VARIANTS.map((v) => (
                <button
                  key={v.key}
                  type="button"
                  onClick={() => setGem(v)}
                  className={`h-12 w-12 rounded border-2 ${gem.key === v.key ? 'border-rbp-accent' : 'border-rbp-border'}`}
                  style={{ backgroundColor: v.color }}
                  title={v.label}
                />
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
