import { Link } from 'react-router-dom'
import { OrangeButton } from '../components/ui/Buttons.tsx'
import { GothicHeading } from '../components/ui/GothicHeading.tsx'
import { IconCart, IconTrash } from '../components/ui/Icons.tsx'
import { QuantityStepper } from '../components/ui/QuantityStepper.tsx'
import { cartLineImage, useCart } from '../features/cart/CartProvider.tsx'
import { useCheckout } from '../hooks/useCheckout.ts'
import { asset } from '../lib/assets.ts'
import { formatPhpLabel } from '../lib/format.ts'

export function CheckoutPage() {
  const { lines, updateQuantity, removeLine, clearCart, itemCount } = useCart()
  const {
    form,
    updateForm,
    step,
    subtotalCents,
    shippingCents,
    totalCents,
    submitOrder,
    submitting,
    orderId,
    error,
  } = useCheckout(lines)

  const handleSubmit = async () => {
    const ok = await submitOrder()
    if (ok) clearCart()
  }

  if (step === 3 && orderId) {
    return (
      <div className="px-6 py-16 text-center">
        <GothicHeading className="text-4xl">Order Confirmed</GothicHeading>
        <p className="mt-4 text-rbp-muted">Reference: {orderId}</p>
        <Link to="/collections" className="mt-8 inline-block text-rbp-accent">
          Continue Shopping →
        </Link>
      </div>
    )
  }

  return (
    <div className="w-full">
      <section className="relative grid w-full lg:grid-cols-2">
        <div className="px-6 py-10 sm:px-12">
          <GothicHeading as="h1" className="text-4xl lg:text-5xl">
            Shopping Cart & Checkout
          </GothicHeading>
          <p className="mt-2 tracking-wide text-rbp-muted text-sm">
            REVIEW YOUR ITEMS AND COMPLETE YOUR ORDER
          </p>
        </div>
        <div className="min-h-[140px] lg:min-h-[179px]">
          <img
            src={asset('banners/checkout-jewelry-banner.jpg')}
            alt="Checkout jewelry"
            className="h-full w-full object-cover"
          />
        </div>
      </section>

      <section className="grid w-full gap-6 px-4 py-6 lg:grid-cols-[1fr_522px] lg:px-8">
        <div className="rounded-rbp border border-rbp-border bg-rbp-surface p-4">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <IconCart size={30} />
              <GothicHeading className="text-2xl">Your Cart</GothicHeading>
              <span className="text-rbp-muted">({itemCount} Items)</span>
            </div>
            <Link to="/collections" className="text-sm text-rbp-accent-gold">
              Continue Shopping →
            </Link>
          </div>

          <div className="border-b border-rbp-border pb-2 text-sm font-bold">
            <div className="grid grid-cols-[1fr_80px_100px_80px_24px] gap-2 px-2">
              <span>Product</span>
              <span>Price</span>
              <span>Quantity</span>
              <span>Total</span>
              <span />
            </div>
          </div>

          {lines.length === 0 ? (
            <p className="py-8 text-center text-rbp-muted">Your cart is empty.</p>
          ) : (
            lines.map((line) => (
              <div
                key={line.lineId}
                className="grid grid-cols-[1fr_80px_100px_80px_24px] items-center gap-2 border-b border-rbp-border py-3 text-sm"
              >
                <div className="flex gap-3">
                  <img
                    src={cartLineImage(line)}
                    alt=""
                    className="h-[72px] w-[89px] rounded object-cover"
                  />
                  <div>
                    <p className="font-bold">{line.name}</p>
                    <p className="text-xs text-rbp-muted">{line.material}</p>
                    {line.sizeLabel && <p className="text-xs text-rbp-muted">{line.sizeLabel}</p>}
                  </div>
                </div>
                <span>{formatPhpLabel(line.priceCents)}</span>
                <QuantityStepper
                  size="sm"
                  value={line.quantity}
                  onChange={(q) => updateQuantity(line.lineId, q)}
                />
                <span>{formatPhpLabel(line.priceCents * line.quantity)}</span>
                <button type="button" aria-label="Remove" onClick={() => removeLine(line.lineId)}>
                  <IconTrash />
                </button>
              </div>
            ))
          )}

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div>
              <p className="mb-2 font-bold">Shipping Options</p>
              <label className="mb-2 flex cursor-pointer items-center gap-3 text-sm">
                <input
                  type="radio"
                  name="ship"
                  checked={form.shippingMethod === 'standard'}
                  onChange={() => updateForm({ shippingMethod: 'standard' })}
                  className="accent-rbp-accent"
                />
                Standard Shipping (3–5 Business Days)
                <span className="ml-auto">{formatPhpLabel(10000)}</span>
              </label>
              <label className="flex cursor-pointer items-center gap-3 text-sm">
                <input
                  type="radio"
                  name="ship"
                  checked={form.shippingMethod === 'express'}
                  onChange={() => updateForm({ shippingMethod: 'express' })}
                  className="accent-rbp-accent"
                />
                Express Shipping (1–2 Business Days)
                <span className="ml-auto">{formatPhpLabel(20000)}</span>
              </label>
            </div>
            <ClientOrderSummary
              subtotalCents={subtotalCents}
              shippingCents={shippingCents}
              totalCents={totalCents}
              itemCount={itemCount}
            />
          </div>
        </div>

        <CheckoutFormPanel
          form={form}
          updateForm={updateForm}
          step={step}
          onSubmit={handleSubmit}
          submitting={submitting}
          error={error}
        />
      </section>
    </div>
  )
}

function ClientOrderSummary({
  subtotalCents,
  shippingCents,
  totalCents,
  itemCount,
}: {
  subtotalCents: number
  shippingCents: number
  totalCents: number
  itemCount: number
}) {
  return (
    <p className="rounded border border-rbp-border p-4 text-sm">
      <span className="text-lg font-bold">Order Summary</span>
      <br />
      <br />
      Subtotal ({itemCount} Items) <span className="float-right">{formatPhpLabel(subtotalCents)}</span>
      <br />
      Shipping <span className="float-right">{formatPhpLabel(shippingCents)}</span>
      <br />
      <hr className="my-2 border-rbp-border" />
      <span className="text-lg font-bold">Total</span>
      <span className="float-right text-lg font-bold">{formatPhpLabel(totalCents)}</span>
    </p>
  )
}

function CheckoutFormPanel({
  form,
  updateForm,
  step,
  onSubmit,
  submitting,
  error,
}: {
  form: ReturnType<typeof useCheckout>['form']
  updateForm: ReturnType<typeof useCheckout>['updateForm']
  step: number
  onSubmit: () => void
  submitting: boolean
  error: string | null
}) {
  const payments = [
    { id: 'gcash' as const, label: 'GCash' },
    { id: 'maya' as const, label: 'Maya' },
    { id: 'gotyme' as const, label: 'GoTyme' },
    { id: 'bank' as const, label: 'Bank Transfer' },
  ]

  return (
    <div className="rounded-rbp border border-rbp-border bg-rbp-surface p-4">
      <div className="mb-6 flex items-center justify-between text-xs">
        {['Information', 'Payment', 'Confirmation'].map((label, i) => (
          <span key={label} className={step >= i + 1 ? 'text-rbp-accent' : 'text-rbp-muted'}>
            {i + 1} {label}
          </span>
        ))}
      </div>

      <p className="mb-3 font-bold">Customer Information</p>
      <FormField label="Full Name *">
        <input
          className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
          value={form.fullName}
          onChange={(e) => updateForm({ fullName: e.target.value })}
          placeholder="Enter your full name"
        />
      </FormField>
      <div className="grid gap-3 sm:grid-cols-2">
        <FormField label="Email Address *">
          <input
            type="email"
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.email}
            onChange={(e) => updateForm({ email: e.target.value })}
            placeholder="Enter your email"
          />
        </FormField>
        <FormField label="Phone Number *">
          <input
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.phone}
            onChange={(e) => updateForm({ phone: e.target.value })}
            placeholder="+63 9XX XXX XXXX"
          />
        </FormField>
      </div>

      <p className="mb-2 mt-4 font-bold">Shipping Address</p>
      <div className="grid gap-3 sm:grid-cols-2">
        <FormField label="Province *">
          <input
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.province}
            onChange={(e) => updateForm({ province: e.target.value })}
          />
        </FormField>
        <FormField label="City / Municipality *">
          <input
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.city}
            onChange={(e) => updateForm({ city: e.target.value })}
          />
        </FormField>
        <FormField label="Barangay *">
          <input
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.barangay}
            onChange={(e) => updateForm({ barangay: e.target.value })}
          />
        </FormField>
        <FormField label="Postal Code *">
          <input
            className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
            value={form.postalCode}
            onChange={(e) => updateForm({ postalCode: e.target.value })}
          />
        </FormField>
      </div>
      <FormField label="Complete Address *">
        <textarea
          className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-sm"
          rows={2}
          value={form.address}
          onChange={(e) => updateForm({ address: e.target.value })}
          placeholder="House No., Street, Subdivision, Landmark"
        />
      </FormField>

      <p className="mb-2 mt-4 font-bold">Payment Method</p>
      <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {payments.map((p) => (
          <button
            key={p.id}
            type="button"
            onClick={() => updateForm({ paymentMethod: p.id })}
            className={`rounded border py-4 text-sm ${
              form.paymentMethod === p.id ? 'border-rbp-accent bg-rbp-bg' : 'border-rbp-border'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {error && <p className="mb-2 text-sm text-red-400">{error}</p>}
      <OrangeButton
        type="button"
        className="w-full py-3"
        disabled={submitting}
        onClick={onSubmit}
      >
        {submitting ? 'Processing…' : 'Proceed to Checkout →'}
      </OrangeButton>
    </div>
  )
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="mb-2 block text-xs text-rbp-muted">
      {label}
      <div className="mt-1">{children}</div>
    </label>
  )
}
