import { Outlet, useLocation } from 'react-router-dom'
import { SiteHeader } from './SiteHeader.tsx'
import { variantFromPath } from './headerConfig.ts'

export function SiteLayout() {
  const { pathname } = useLocation()
  const variant = variantFromPath(pathname)

  return (
    <div className="flex min-h-screen w-full flex-col bg-rbp-bg">
      <SiteHeader variant={variant} />
      <main className="w-full flex-1">
        <Outlet />
      </main>
    </div>
  )
}