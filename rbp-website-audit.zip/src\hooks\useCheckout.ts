import { useState } from 'react'
import type { CartLine, CheckoutForm } from '../data/types.ts'
import { supabase } from '../lib/supabase.ts'

const SHIPPING_CENTS = { standard: 10000, express: 20000 } as const

export function useCheckout(lines: CartLine[]) {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [submitting, setSubmitting] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [form, setForm] = useState<CheckoutForm>({
    fullName: '',
    email: '',
    phone: '',
    province: '',
    city: '',
    barangay: '',
    postalCode: '',
    address: '',
    paymentMethod: 'gcash',
    shippingMethod: 'standard',
  })

  const subtotalCents = lines.reduce(
    (n, l) => n + l.priceCents * l.quantity,
    0,
  )
  const shippingCents = SHIPPING_CENTS[form.shippingMethod]
  const totalCents = subtotalCents + shippingCents

  const updateForm = (patch: Partial<CheckoutForm>) => {
    setForm((prev) => ({ ...prev, ...patch }))
  }

  const submitOrder = async () => {
    setError(null)
    if (!form.fullName || !form.email || !form.phone) {
      setError('Please fill in required customer fields.')
      return false
    }
  if (lines.length === 0) {
      setError('Your cart is empty.')
      return false
    }

    if (!supabase) {
      setOrderId(`local-${Date.now()}`)
      setStep(3)
      return true
    }

    setSubmitting(true)
    try {
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          status: 'pending',
          subtotal_cents: subtotalCents,
          shipping_cents: shippingCents,
          total_cents: totalCents,
          payment_method: form.paymentMethod,
          shipping_address: {
            fullName: form.fullName,
            email: form.email,
            phone: form.phone,
            province: form.province,
            city: form.city,
            barangay: form.barangay,
            postalCode: form.postalCode,
            address: form.address,
            shippingMethod: form.shippingMethod,
          },
        })
        .select('id')
        .single()

      if (orderError) throw orderError

      const items = lines.map((line) => ({
        order_id: order.id,
        product_id: line.productId,
        variant_key: line.variantKey ?? null,
        quantity: line.quantity,
        unit_price_cents: line.priceCents,
        product_name: line.name,
      }))

      const { error: itemsError } = await supabase.from('order_items').insert(items)
      if (itemsError) throw itemsError

      setOrderId(order.id as string)
      setStep(3)
      return true
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Checkout failed')
      return false
    } finally {
      setSubmitting(false)
    }
  }

  return {
    form,
    updateForm,
    step,
    setStep,
    subtotalCents,
    shippingCents,
    totalCents,
    submitOrder,
    submitting,
    orderId,
    error,
  }
}