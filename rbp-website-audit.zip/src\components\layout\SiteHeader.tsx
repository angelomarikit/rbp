import { Link, useLocation } from 'react-router-dom'
import { useCart } from '../../features/cart/CartProvider.tsx'
import { LOGO } from '../../lib/assets.ts'
import { IconCart, IconSearch, IconUser } from '../ui/Icons.tsx'
import { OrangeBorderDivider } from '../ui/OrangeDivider.tsx'
import {
  NAV_CHECKOUT,
  NAV_COLLECTIONS,
  NAV_EVENTS,
  NAV_HOME,
  NAV_PRODUCT,
  type HeaderVariant,
  type NavItem,
} from './headerConfig.ts'

const navByVariant: Record<HeaderVariant, NavItem[]> = {
  home: NAV_HOME,
  collections: NAV_COLLECTIONS,
  product: NAV_PRODUCT,
  checkout: NAV_CHECKOUT,
  events: NAV_EVENTS,
}

const heightByVariant: Record<HeaderVariant, string> = {
  home: 'min-h-[54px] lg:min-h-[132px]',
  collections: 'min-h-[111px]',
  product: 'min-h-[133px]',
  checkout: 'min-h-[77px]',
  events: 'min-h-[79px]',
}

function isActive(item: NavItem, pathname: string) {
  if (item.match?.some((m) => pathname === m || pathname.startsWith(m))) return true
  if (item.to.split('#')[0] === pathname) return true
  return false
}

export function SiteHeader({ variant }: { variant: HeaderVariant }) {
  const { pathname } = useLocation()
  const { itemCount } = useCart()
  const nav = navByVariant[variant]
  const uppercase = variant !== 'home' && variant !== 'checkout' && variant !== 'events'
  const showTagline = variant === 'product'
  const showWordmark = variant === 'collections' || variant === 'checkout' || variant === 'events'
  const logoSize =
    variant === 'home'
      ? 'h-[48px] w-[48px] lg:absolute lg:left-10 lg:top-1 lg:h-[92px] lg:w-[92px]'
      : variant === 'collections'
        ? 'h-[75px] w-[75px]'
        : variant === 'events'
          ? 'h-[67px] w-[67px]'
          : 'h-[70px] w-[70px]'

  return (
    <header className={`relative w-full bg-rbp-bg ${heightByVariant[variant]}`}>
      <div className="mx-auto flex w-full flex-col px-4 pt-2 sm:px-8 lg:px-10">
        <div className="flex flex-wrap items-start gap-3 lg:flex-nowrap lg:items-center">
          <Link to="/" className="relative z-20 shrink-0">
            <img src={LOGO} alt="Romell Body Piercing" className={`object-contain ${logoSize}`} />
          </Link>

          <div className="flex min-w-0 flex-1 flex-col gap-1 lg:pl-28">
            {showWordmark && (
              <p className="font-display text-xl leading-none text-rbp-accent sm:text-2xl lg:border-l lg:border-rbp-border lg:pl-4 lg:text-[2rem]">
                Romell Body Piercing
              </p>
            )}

            {variant === 'home' && (
              <p className="hidden tracking-[4px] text-rbp-muted text-xs lg:block">
                ROMELL BODY PIERCING
              </p>
            )}

            {showTagline && (
              <p className="hidden text-[10px] tracking-wide text-rbp-muted lg:block">
                PIERCING JEWELRY • BODY MODIFICATION • PROFESSIONAL PIERCING
              </p>
            )}

            <nav
              className={`flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] lg:gap-x-5 ${
                variant === 'product' ? 'border-t border-rbp-border-light pt-2' : ''
              } ${variant === 'checkout' || variant === 'events' ? 'lg:ml-auto' : ''}`}
            >
              {nav.map((item) => {
                const active = isActive(item, pathname)
                return (
                  <Link
                    key={item.label}
                    to={item.to}
                    className={`relative whitespace-nowrap pb-1 ${
                      active ? 'text-rbp-accent' : 'text-rbp-text hover:text-rbp-accent'
                    } ${uppercase ? 'text-xs uppercase tracking-wide sm:text-sm' : ''}`}
                  >
                    {item.label}
                    {active && (
                      <span
                        className={`absolute bottom-0 left-0 bg-rbp-accent ${
                          variant === 'collections' ? 'h-2 w-full' : 'h-0.5 w-full'
                        }`}
                      />
                    )}
                  </Link>
                )
              })}
            </nav>
          </div>

          <div className="ml-auto flex shrink-0 items-center gap-3 lg:gap-4">
            {variant === 'product' && (
              <div className="mr-2 hidden min-w-[280px] items-center gap-2 rounded border border-rbp-border px-3 py-2 lg:flex">
                <IconSearch size={20} />
                <span className="text-xs text-rbp-muted">Search jewelry, piercings, collections...</span>
              </div>
            )}
            {variant !== 'product' && <IconSearch />}
            <IconUser size={variant === 'product' ? 25 : 21} />
            {variant === 'product' && (
              <button type="button" aria-label="Wishlist" className="hidden lg:block">
                <svg width={25} height={25} viewBox="0 0 24 24" fill="none" aria-hidden>
                  <path
                    d="M12 21s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 11c0 5.6-7 10-7 10z"
                    stroke="#ff8500"
                    strokeWidth="1.5"
                  />
                </svg>
              </button>
            )}
            <Link to="/checkout" className="relative">
              <IconCart size={variant === 'events' ? 19 : 22} />
              <span className="absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-rbp-accent px-1 text-[11px] text-white">
                {itemCount}
              </span>
            </Link>
          </div>
        </div>
      </div>
      <OrangeBorderDivider className="absolute bottom-0 left-0" />
    </header>
  )
}