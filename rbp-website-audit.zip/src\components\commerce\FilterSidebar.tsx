import { CATEGORY_FILTERS, MATERIAL_FILTERS } from '../../data/products.ts'

export type FilterState = {
  categories: string[]
  materials: string[]
  barLength: string
  gauge: string
}

type Props = {
  filters: FilterState
  onChange: (next: FilterState) => void
}

export function FilterSidebar({ filters, onChange }: Props) {
  const toggle = (key: 'categories' | 'materials', id: string) => {
    const set = new Set(filters[key])
    if (set.has(id)) set.delete(id)
    else set.add(id)
    onChange({ ...filters, [key]: [...set] })
  }

  return (
    <aside className="w-full shrink-0 rounded-rbp border border-rbp-border bg-rbp-surface p-3 lg:w-[187px]">
      <p className="mb-3 text-sm font-bold text-rbp-text">Collections</p>
      <ul className="space-y-2 text-[13px] text-rbp-muted">
        {CATEGORY_FILTERS.map((c) => (
          <li key={c.id} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={filters.categories.includes(c.id)}
              onChange={() => toggle('categories', c.id)}
              className="accent-rbp-accent"
            />
            <span>
              {c.label} ({c.count})
            </span>
          </li>
        ))}
      </ul>
      <div className="my-4 h-px bg-rbp-border" />
      <p className="mb-3 text-sm font-bold">Material</p>
      <ul className="space-y-2 text-[13px] text-rbp-muted">
        {MATERIAL_FILTERS.map((m) => (
          <li key={m.id} className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={filters.materials.includes(m.id)}
              onChange={() => toggle('materials', m.id)}
              className="accent-rbp-accent"
            />
            <span>
              {m.label} ({m.count})
            </span>
          </li>
        ))}
      </ul>
      <div className="my-4 h-px bg-rbp-border" />
      <p className="mb-2 text-sm font-bold">Size</p>
      <p className="mb-1 text-xs text-rbp-muted">Bar Length</p>
      <select
        value={filters.barLength}
        onChange={(e) => onChange({ ...filters, barLength: e.target.value })}
        className="mb-3 w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-xs"
      >
        <option value="all">All Lengths</option>
        <option value="8mm">8 mm</option>
        <option value="10mm">10 mm</option>
      </select>
      <p className="mb-1 text-xs text-rbp-muted">Gauge (Thickness)</p>
      <select
        value={filters.gauge}
        onChange={(e) => onChange({ ...filters, gauge: e.target.value })}
        className="w-full rounded border border-rbp-border bg-rbp-bg px-2 py-1.5 text-xs"
      >
        <option value="all">All Gauges</option>
        <option value="14g">14G</option>
        <option value="16g">16G</option>
      </select>
    </aside>
  )
}