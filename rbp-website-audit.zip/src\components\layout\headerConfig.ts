export type HeaderVariant = 'home' | 'collections' | 'product' | 'checkout' | 'events'

export type NavItem = {
  label: string
  to: string
  match?: string[]
}

export const NAV_HOME: NavItem[] = [
  { label: 'Home', to: '/', match: ['/'] },
  { label: 'Shop ⌄', to: '/collections' },
  { label: 'Collections', to: '/collections', match: ['/collections'] },
  { label: 'Piercing Services', to: '/events' },
  { label: 'Events', to: '/events', match: ['/events'] },
  { label: 'Gallery', to: '/events#showcase' },
  { label: 'About', to: '/events' },
  { label: 'Contact', to: '/checkout' },
]

export const NAV_COLLECTIONS: NavItem[] = [
  { label: 'HOME', to: '/' },
  { label: 'SHOP ⌄', to: '/collections' },
  { label: 'COLLECTIONS', to: '/collections', match: ['/collections'] },
  { label: 'EVENTS', to: '/events' },
  { label: 'ABOUT', to: '/events' },
  { label: 'CONTACT', to: '/checkout' },
]

export const NAV_PRODUCT: NavItem[] = [
  { label: 'HOME', to: '/' },
  { label: 'SHOP ⌄', to: '/collections' },
  { label: 'COLLECTIONS ⌄', to: '/collections' },
  { label: 'PIERCING SERVICES', to: '/events' },
  { label: 'EVENTS', to: '/events' },
  { label: 'ABOUT', to: '/events' },
  { label: 'CONTACT', to: '/checkout' },
]

export const NAV_CHECKOUT: NavItem[] = [
  { label: 'Home', to: '/' },
  { label: 'Shop ⌄', to: '/collections' },
  { label: 'Collections', to: '/collections' },
  { label: 'Events', to: '/events' },
  { label: 'About', to: '/events' },
  { label: 'Contact', to: '/checkout' },
]

export const NAV_EVENTS: NavItem[] = [
  { label: 'Home', to: '/' },
  { label: 'Shop ⌄', to: '/collections' },
  { label: 'Collections', to: '/collections' },
  { label: 'Events', to: '/events', match: ['/events'] },
  { label: 'Client Showcase', to: '/events#showcase' },
  { label: 'About', to: '/events' },
  { label: 'Contact', to: '/checkout' },
]

export function variantFromPath(pathname: string): HeaderVariant {
  if (pathname === '/') return 'home'
  if (pathname.startsWith('/collections')) return 'collections'
  if (pathname.startsWith('/products')) return 'product'
  if (pathname.startsWith('/checkout')) return 'checkout'
  if (pathname.startsWith('/events')) return 'events'
  return 'home'
}