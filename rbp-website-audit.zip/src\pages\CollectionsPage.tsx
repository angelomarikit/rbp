import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { FilterSidebar, type FilterState } from '../components/commerce/FilterSidebar.tsx'
import { ProductCard } from '../components/commerce/ProductCard.tsx'
import { GothicHeading } from '../components/ui/GothicHeading.tsx'
import { IconSearch } from '../components/ui/Icons.tsx'
import { OrangeDivider } from '../components/ui/OrangeDivider.tsx'
import { FEATURED_PRODUCT_SLUG } from '../data/products.ts'
import { useProducts } from '../hooks/useProducts.ts'
import { asset } from '../lib/assets.ts'

const categorySlug: Record<string, string> = {
  'Navel Jewelry': 'navel',
  'Tongue Barbells': 'tongue',
  'Hinged Clickers': 'hinged',
  'Segment Rings': 'segment',
  'Labret / Lip': 'labret',
  Eyebrow: 'eyebrow',
  'Ear Jewelry': 'ear',
}

export function CollectionsPage() {
  const { products } = useProducts()
  const [params] = useSearchParams()
  const initialCat = params.get('category')

  const [filters, setFilters] = useState<FilterState>({
    categories: initialCat
      ? [categorySlug[initialCat] ?? 'navel'].filter(Boolean)
      : [],
    materials: [],
    barLength: 'all',
    gauge: 'all',
  })
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState('bestselling')

  const catalog = useMemo(() => {
    return products.filter((p) => p.slug !== FEATURED_PRODUCT_SLUG)
  }, [products])

  const filtered = useMemo(() => {
    let list = [...catalog]
    if (query) {
      const q = query.toLowerCase()
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q),
      )
    }
    if (filters.categories.length) {
      list = list.filter((p) => {
        const id = categorySlug[p.category]
        return id && filters.categories.includes(id)
      })
    }
    if (filters.materials.length) {
      list = list.filter((p) => {
        if (filters.materials.includes('titanium') && p.material.includes('Titanium')) return true
        if (filters.materials.includes('316l') && p.material.includes('316')) return true
        if (filters.materials.includes('gold') && p.material.includes('Gold')) return true
        return false
      })
    }
    if (sort === 'price-asc') list.sort((a, b) => a.priceCents - b.priceCents)
    if (sort === 'price-desc') list.sort((a, b) => b.priceCents - a.priceCents)
    return list
  }, [catalog, filters, query, sort])

  return (
    <div className="w-full">
      <section className="relative grid w-full lg:grid-cols-[minmax(0,478px)_1fr]">
        <div className="px-6 py-8 sm:px-12 lg:py-10">
          <p className="text-sm uppercase tracking-widest text-rbp-muted">SHOP OUR</p>
          <GothicHeading as="h1" className="text-5xl lg:text-6xl">
            Collections
          </GothicHeading>
          <p className="mt-3 max-w-md text-sm text-rbp-text">
            Premium body jewelry for every style, placement, and piercing.
          </p>
          <div className="mt-3 h-3.5 w-[min(100%,350px)] bg-gradient-to-r from-rbp-accent to-transparent opacity-70" />
        </div>
        <div className="min-h-[160px] lg:min-h-[199px]">
          <img
            src={asset('banners/homepage-studio-sign.jpg')}
            alt="Jewelry collections"
            className="h-full w-full object-cover"
          />
        </div>
        <OrangeDivider className="col-span-full" />
      </section>

      <section className="flex w-full flex-col gap-6 px-4 py-6 lg:flex-row lg:px-6">
        <FilterSidebar filters={filters} onChange={setFilters} />
        <div className="min-w-0 flex-1">
          <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <GothicHeading className="text-2xl">All Collections</GothicHeading>
              <p className="text-xs text-rbp-muted">
                Showing 1–{filtered.length} of 240 products
              </p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <label className="flex items-center gap-2 rounded border border-rbp-border bg-rbp-surface px-3 py-2 text-xs">
                <IconSearch size={17} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search jewelry (e.g. navel, ring, barbell...)"
                  className="min-w-[200px] flex-1 bg-transparent outline-none"
                />
              </label>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="rounded border border-rbp-border bg-rbp-surface px-3 py-2 text-xs"
              >
                <option value="bestselling">Sort by: Best Selling</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}