import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { OrangeButton, OutlineButton } from '../components/ui/Buttons.tsx'
import { GothicHeading } from '../components/ui/GothicHeading.tsx'
import { IconCalendarLight, IconChevron, IconPin } from '../components/ui/Icons.tsx'
import { OrangeDivider } from '../components/ui/OrangeDivider.tsx'
import { asset } from '../lib/assets.ts'

const featuredEvents = [
  {
    title: 'Philippine Tattoo Expo 2025',
    image: 'events/featured-event-1.jpg',
    date: 'May 16–18, 2025',
    location: 'SMX Convention Center, Pasay',
  },
  {
    title: 'RBP Body Piercing Seminar',
    image: 'events/featured-event-2.jpg',
    date: 'Mar 22, 2025',
    location: 'Quezon City, Metro Manila',
  },
  {
    title: 'Body Piercers Association Convention',
    image: 'events/featured-event-3.jpg',
    date: 'Feb 8–9, 2025',
    location: 'Manila, Philippines',
  },
]

const upcoming = [
  { title: 'PBF Tattoo & Piercing Expo', date: 'Jan 23–25, 2026' },
  { title: 'RBP Piercing Workshop', date: 'Feb 14, 2026' },
  { title: 'Manila Tattoo Convention', date: 'Mar 27–29, 2026' },
]

const showcaseImages = [
  'showcase/event-client-result-1.jpg',
  'showcase/event-client-result-2.jpg',
  'showcase/event-client-result-3.jpg',
  'showcase/event-client-result-4.jpg',
  'showcase/event-client-result-5.jpg',
  'showcase/event-client-result-6.jpg',
]

const testimonials = [
  {
    quote: 'Super professional and clean process. The piercing healed really well!',
    author: 'Bianca T.',
  },
  {
    quote: 'The best piercing experience I’ve had. Highly recommended for quality and safety.',
    author: 'Mark R.',
  },
  {
    quote: 'Amazing service and wide selection of jewelry. Will definitely come back!',
    author: 'Camille S.',
  },
]

export function EventsPage() {
  const navigate = useNavigate()
  const [slide, setSlide] = useState(0)
  const perView = 6
  const maxSlide = Math.max(0, showcaseImages.length - 3)

  return (
    <div className="w-full">
      <section className="relative grid w-full border-b border-rbp-divider lg:grid-cols-[minmax(0,323px)_1fr]">
        <div className="px-6 py-8 sm:px-10">
          <p className="text-xs uppercase tracking-widest text-rbp-muted">EVENTS &</p>
          <GothicHeading as="h1" className="text-4xl lg:text-5xl">
            Client Showcase
          </GothicHeading>
          <div className="mt-2 h-3 w-[270px] max-w-full bg-gradient-to-r from-rbp-accent to-transparent opacity-80" />
          <p className="mt-3 max-w-xs text-sm text-rbp-text">
            Take a closer look at our events, piercing work, and the community that continues to support the RBP
            movement.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <OrangeButton onClick={() => navigate('/checkout')}>Book a Piercing</OrangeButton>
            <OutlineButton onClick={() => document.getElementById('showcase')?.scrollIntoView({ behavior: 'smooth' })}>
              View Gallery
            </OutlineButton>
          </div>
        </div>
        <div className="min-h-[180px] lg:min-h-[199px]">
          <img
            src={asset('events/expo-main-hero.jpg')}
            alt="Tattoo expo booth"
            className="h-full w-full object-cover"
          />
        </div>
      </section>

      <section className="px-4 py-8 sm:px-8">
        <GothicHeading className="mb-6 text-center text-3xl">Featured Events</GothicHeading>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {featuredEvents.map((ev) => (
            <article key={ev.title} className="overflow-hidden rounded-rbp border border-rbp-border bg-rbp-card">
              <img src={asset(ev.image)} alt={ev.title} className="h-[90px] w-full object-cover" />
              <div className="p-3 text-xs">
                <p className="text-sm font-bold text-rbp-text">{ev.title}</p>
                <p className="mt-2 flex items-center gap-1 text-rbp-muted">
                  <IconCalendarLight size={11} /> {ev.date}
                </p>
                <p className="flex items-center gap-1 text-rbp-muted">
                  <IconPin size={11} /> {ev.location}
                </p>
              </div>
            </article>
          ))}
          <aside className="rounded-rbp border border-rbp-border bg-rbp-surface p-3 text-xs">
            <p className="mb-3 flex items-center gap-2 font-bold text-rbp-accent">
              <IconCalendarLight size={19} /> Upcoming Events
            </p>
            <ul className="space-y-3">
              {upcoming.map((u) => (
                <li key={u.title} className="border-b border-rbp-border pb-2">
                  <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-rbp-accent" />
                  {u.title}
                  <br />
                  <span className="ml-3 text-rbp-muted">{u.date}</span>
                </li>
              ))}
            </ul>
          </aside>
        </div>
        <OrangeDivider className="mt-6" />
      </section>

      <section className="grid w-full gap-4 border-b border-rbp-divider px-4 py-6 lg:grid-cols-[240px_1fr] lg:px-8">
        <div>
          <GothicHeading className="text-2xl">The Piercing Process</GothicHeading>
          <p className="mt-2 text-sm text-rbp-text">Safe. Sterile. Professional.</p>
          <div className="mt-2 h-3 w-40 bg-gradient-to-r from-rbp-accent to-transparent opacity-70" />
        </div>
        <img
          src={asset('romell/romell-piercing-client-action-original.png')}
          alt="Professional piercing procedure"
          className="h-[102px] w-full rounded-rbp border border-rbp-border object-cover lg:object-right"
        />
      </section>

      <section id="showcase" className="px-4 py-8 sm:px-8">
        <GothicHeading className="text-center text-3xl">Client Showcase</GothicHeading>
        <p className="mb-6 text-center text-[9px] tracking-widest text-rbp-muted">
          REAL CLIENTS • REAL PIERCINGS • REAL RESULTS
        </p>
        <div className="relative flex items-center gap-2">
          <button
            type="button"
            aria-label="Previous"
            className="rounded-full border border-rbp-border p-2"
            onClick={() => setSlide((s) => Math.max(0, s - 1))}
          >
            <IconChevron direction="left" />
          </button>
          <div className="flex flex-1 gap-2 overflow-hidden">
            {showcaseImages.slice(slide, slide + perView).map((src) => (
              <img
                key={src}
                src={asset(src)}
                alt="Client showcase"
                className="h-[111px] min-w-[120px] flex-1 rounded-rbp object-cover"
              />
            ))}
          </div>
          <button
            type="button"
            aria-label="Next"
            className="rounded-full border border-rbp-border p-2"
            onClick={() => setSlide((s) => Math.min(maxSlide, s + 1))}
          >
            <IconChevron direction="right" />
          </button>
        </div>
        <div className="mt-4 flex justify-center gap-2">
          {[0, 1, 2, 3, 4].map((i) => (
            <span
              key={i}
              className={`h-2 w-2 rounded-full ${i === slide ? 'bg-rbp-accent' : 'bg-rbp-border'}`}
            />
          ))}
        </div>
      </section>

      <section className="grid gap-4 border-t border-rbp-divider px-4 py-8 sm:grid-cols-2 lg:grid-cols-5 lg:px-8">
        <GothicHeading className="text-2xl leading-tight lg:col-span-1">
          What Our
          <br />
          Clients Say
        </GothicHeading>
        {testimonials.map((t) => (
          <blockquote
            key={t.author}
            className="rounded-rbp border border-rbp-border bg-rbp-surface p-3 text-xs text-rbp-text"
          >
            <p className="italic">“{t.quote}”</p>
            <p className="mt-2 text-rbp-accent">★★★★★</p>
            <p className="text-rbp-muted">– {t.author}</p>
          </blockquote>
        ))}
        <aside className="rounded-rbp border border-rbp-accent bg-rbp-card p-3 text-xs lg:col-span-1">
          <p className="font-bold text-rbp-accent">Book Your Piercing Now</p>
          <p className="mt-2 text-rbp-muted">Consultation • Proper Guidance • Aftercare Support</p>
          <OrangeButton className="mt-3 w-full text-xs" onClick={() => navigate('/checkout')}>
            Book an Appointment →
          </OrangeButton>
        </aside>
      </section>
    </div>
  )
}